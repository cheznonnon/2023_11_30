//
//  main.m
//  Nonnon Typing
//
//  Created by のんのん on 2023/08/18.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
	@autoreleasepool {
	    // Setup code that might create autoreleased objects goes here.
	}
	return NSApplicationMain(argc, argv);
}
