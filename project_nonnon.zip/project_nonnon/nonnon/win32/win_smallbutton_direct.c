// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [ Mechanism ]
//
//	this file is made for Nonnon TxtBox, use win_smallbutton.c for Win32 edit controls
//
//	[ Usage ]
//
//	Init       : n_win_smallbutton_direct_zero()
//	WM_CREATE  : n_win_smallbutton_direct_init()
//	WM_CLOSE   : n_win_smallbutton_direct_exit()
//
//	[ Optional ]
//
//	WM_SETTINGCHANGE : n_win_smallbutton_direct_on_settingchange()
//
//	[ Icon Resource ]
//
//	a gray-scaled icon will be a system-colored icon automatically
//	see n_win_smallbutton_direct_bitmap() for details
//
//	[ Tips ]
//
//	Not Used        : .m and .icon is not used in main purpose
//
//	init_by_data()  : you can use a on-the-fly resource : see win32/win_combobox.c
//
//	.show_onoff     : EnableWindow()-like behavior, default is false
//	.bmp_canvas     : direct render mode




#ifndef _H_NONNON_WIN32_WIN_SMALLBUTTON_DIRECT
#define _H_NONNON_WIN32_WIN_SMALLBUTTON_DIRECT




#include "../neutral/bmp/fade.c"
#include "../neutral/bmp/filter.c"
#include "../neutral/bmp/transform.c"

#include "./win.c"
#include "./gdi/bitmap.c"
#include "./gdi/color.c"




#define N_WIN_SMALLBUTTON_DIRECT_NONE    ( 0 << 0 )
#define N_WIN_SMALLBUTTON_DIRECT_NORMAL  ( 1 << 0 )
#define N_WIN_SMALLBUTTON_DIRECT_HOVERED ( 1 << 1 )
#define N_WIN_SMALLBUTTON_DIRECT_PRESSED ( 1 << 2 )


typedef struct {

	HWND         hwnd_draw;
	HWND         hwnd_timer;
	HWND         hwnd_msg;
	int          id;
	n_type_gfx   scale;
	n_type_gfx   x,y,sx,sy;
	n_type_gfx   old_x,old_y,old_sx,old_sy;
	int          state;
	n_posix_bool show_onoff;
	n_posix_bool combine_onoff;

	HICON        hicon;
	n_bmp        b,m;
	n_bmp        bmp_default;
	n_bmp        bmp;
	n_bmp       *bmp_canvas;

	n_posix_bool make_default;

	n_bmp_fade   fade;
	u32          fade_timer;
	n_posix_bool fade_onoff;
	n_type_real  fade_blend;

	u32          color_box_u;
	u32          color_box_d;

	// [!] : you can override colors

	u32          color_fg;
	u32          color_bg;
	u32          color_pressed;
	u32          color_hovered;

} n_win_smallbutton_direct;


#define n_win_smallbutton_direct_zero( p ) n_memory_zero( p, sizeof( n_win_smallbutton_direct ) )




void
n_win_smallbutton_direct_bitmap_make( const u8 *data, n_bmp *bmp_ret, n_type_gfx scale, u32 color_bg )
{

	n_type_gfx sx = 16;
	n_type_gfx sy = 16;

	n_bmp bmp; n_bmp_zero( &bmp ); n_bmp_1st_fast( &bmp, sx,sy );
	n_bmp_flush( &bmp, color_bg );

	n_type_gfx x = 0;
	n_type_gfx y = 0;
	n_posix_loop
	{

		int value = data[ x + ( y * sx ) ];

		u32 color;
		if ( value == 255 )
		{
			color = color_bg;
		} else {
			color = n_bmp_rgb( value,value,value );
		}

		n_bmp_ptr_set_fast( &bmp, x,y, color );

		x++;
		if ( x >= sx )
		{
			x = 0;
			y++;
			if ( y >= sy ) { break; }
		}
	}

	n_type_gfx size = 32 * scale;
	n_bmp_resizer( &bmp, size,size, color_bg, N_BMP_RESIZER_CENTER );

	n_bmp_free_fast( bmp_ret );
	n_bmp_alias( &bmp, bmp_ret );


	return;
}

void
n_win_smallbutton_direct_bitmap_reverse( n_win_smallbutton_direct *p, n_bmp *bmp )
{

	n_type_int c = N_BMP_SX( bmp ) * N_BMP_SY( bmp );
	n_type_int i = 0;
	n_posix_loop
	{

		u32 color = N_BMP_PTR( bmp )[ i ];

		int r = 255 - n_bmp_r( color );
		int g = 255 - n_bmp_g( color );
		int b = 255 - n_bmp_b( color );

		N_BMP_PTR( bmp )[ i ] = n_bmp_rgb( r,g,b );

		i++;
		if ( i >= c ) { break; }
	}


	return;
}

void
n_win_smallbutton_direct_bitmap_contour( n_win_smallbutton_direct *p, n_type_gfx ox, n_type_gfx oy, u32 color_fg )
{

	n_bmp bmp_tmp; n_bmp_carboncopy( &p->bmp_default, &bmp_tmp );

	n_type_gfx m = p->scale * 1;
	n_type_gfx x = -m;
	n_type_gfx y = -m;
	n_posix_loop
	{//break;

		n_bmp_rasterizer( &bmp_tmp, &p->bmp, ox + x, oy + y, n_bmp_white, n_posix_false );

		x++;
		if ( x > m )
		{
			x = -m;

			y++;
			if ( y > m ) { break; }
		}
	}

	n_bmp_antialias( &p->bmp, ox-m,oy-m, p->sx+(m*2),p->sy+(m*2), 1.0 );

	n_bmp_rasterizer( &bmp_tmp, &p->bmp, ox,oy, color_fg, n_posix_false );

	n_bmp_free_fast( &bmp_tmp );


	return;
}

void
n_win_smallbutton_direct_bitmap_draw( n_win_smallbutton_direct *p )
{

	if ( p == NULL ) { return; }


	if ( p->show_onoff )
	{
		if ( ( p->bmp_canvas != NULL )&&( NULL != N_BMP_PTR( p->bmp_canvas ) ) )
		{

			// [x] : combobox : AeroGlass : upper-side is used as highlight

			// [x] : not working
			//n_win_redraw( p->hwnd_draw, n_posix_true );

			n_type_gfx tx  = p->x;
			n_type_gfx ty  = p->y;
			n_type_gfx tsx = p->sx;
			n_type_gfx tsy = p->sy;

			n_bmp_box( p->bmp_canvas, tx,ty      , tsx,tsy/2, p->color_box_u );
			n_bmp_box( p->bmp_canvas, tx,ty+tsy/2, tsx,tsy/2, p->color_box_d );

			{
				n_type_gfx  x = p->x;
				n_type_gfx  y = p->y;
				n_type_gfx sx = p->sx;
				n_type_gfx sy = p->sy;

				n_bmp_blendcopy( &p->bmp, p->bmp_canvas, 0,0,sx,sy, x,y, p->fade_blend );
			}

		} else {

			n_gdi_bitmap_draw( p->hwnd_draw, &p->bmp, 0,0,p->sx,p->sy, p->x,p->y );

		}

//n_bmp_box( p->bmp_canvas, 0, 0, 1000, 1000, n_bmp_rgb( 0,200,255 ) );
//n_bmp_box( p->bmp_canvas, p->x, p->y, p->sx, p->sy, n_bmp_rgb( 0,200,255 ) );
//n_bmp_save_literal( &p->bmp, "bitmap_draw.bmp" );
	}


	return;
}

void
n_win_smallbutton_direct_bitmap_init( n_win_smallbutton_direct *p )
{

	if ( p == NULL ) { return; }


	if ( p->make_default )
	{
		p->make_default = n_posix_false;

		n_bmp_free( &p->bmp_default );
		n_bmp_carboncopy( &p->b, &p->bmp_default );

		n_bmp_scaler_big( &p->bmp_default, p->scale );

		n_bmp_resizer( &p->bmp_default, p->sx,p->sy, p->color_bg, N_BMP_RESIZER_CENTER );

		n_win_smallbutton_direct_bitmap_reverse( p, &p->bmp_default );
//n_bmp_save_literal( &p->bmp_default, "bmp_default.bmp" );
	}


	n_type_gfx ox = 0;
	n_type_gfx oy = 0;

	if ( p->state & N_WIN_SMALLBUTTON_DIRECT_PRESSED )
	{
		ox =  p->scale;
		oy =  p->scale;
	}


	u32 color_fg;

	if ( p->state & N_WIN_SMALLBUTTON_DIRECT_PRESSED )
	{

		if ( p->state & N_WIN_SMALLBUTTON_DIRECT_HOVERED )
		{
			color_fg = n_bmp_fade_engine( &p->fade, n_win_fade_is_on() );
		} else {
			color_fg = p->color_pressed;
		}

	} else {

		color_fg = n_bmp_fade_engine( &p->fade, n_win_fade_is_on() );
//if ( p->id == 1 ) { n_win_hwndprintf_literal( n_win_hwnd_toplevel( p->hwnd_draw ), " %d ", p->fade.percent ); }

	}


	//n_bmp_free( &p->bmp );
	n_bmp_new_fast( &p->bmp, p->sx,p->sy );
	n_bmp_flush( &p->bmp, p->color_bg );

	n_win_smallbutton_direct_bitmap_contour( p, ox,oy, color_fg );
//n_bmp_save_literal( &p->bmp, "contour.bmp" );


	return;
}

void
n_win_smallbutton_direct_bitmap_init_lite( n_win_smallbutton_direct *p )
{

	if ( p == NULL ) { return; }


	n_type_gfx ox = 0;
	n_type_gfx oy = 0;

	if ( p->state & N_WIN_SMALLBUTTON_DIRECT_PRESSED )
	{
		ox =  p->scale;
		oy =  p->scale;
	}


	n_bmp_new_fast( &p->bmp, p->sx,p->sy );
	n_bmp_flush( &p->bmp, p->color_bg );

	u32 color_fg = n_bmp_fade_engine( &p->fade, n_win_fade_is_on() );

	n_win_smallbutton_direct_bitmap_contour( p, ox,oy, color_fg );


	return;
}

// [x] : curretly not working

//#define n_win_smallbutton_direct_on_settingchange(         p, i ) n_win_smallbutton_direct_on_settingchange_internal( p, i, NULL )
//#define n_win_smallbutton_direct_on_settingchange_by_data( p, d ) n_win_smallbutton_direct_on_settingchange_internal( p, 0,    d )

// internal
void
n_win_smallbutton_direct_on_settingchange_internal( n_win_smallbutton_direct *p, int index, const u8 *data )
{

	// Resource

	p->scale = (n_type_gfx) trunc( n_win_scale( GetDesktopWindow() ) );

	n_win_stdsize_icon_large( &p->sx, &p->sy );

	if ( data == NULL )
	{
		p->hicon = n_win_icon_init( NULL, index, N_WIN_ICON_INIT_OPTION_RESOURCE );
		n_win_icon_hicon2bmp_1st( p->hicon, p->sx,p->sy, &p->b, &p->m );
//n_bmp_save_literal( &p->b, "ret.bmp" );

		// [x] : High-DPI : Patch
		n_bmp_fill( &p->b, 0,0, p->color_bg );
	} else {
		n_win_smallbutton_direct_bitmap_make( data, &p->b, p->scale, n_bmp_white_invisible );
//n_bmp_free( &p->b );
//n_bmp_new( &p->b, 32,32 );
	}


	// [!] : default colors

	p->color_bg = n_bmp_white_invisible;

	if ( n_win_darkmode_onoff )
	{
		p->color_fg      = n_gdi_systemcolor( COLOR_GRAYTEXT   );
		p->color_pressed = n_gdi_systemcolor( COLOR_3DDKSHADOW );
		//p->color_hovered = n_gdi_systemcolor( COLOR_HIGHLIGHT  );
		//p->color_hovered = n_bmp_hsl_replace_pixel( p->color_hovered, -1, 255, 128 );
		p->color_hovered = n_win_dwm_windowcolor_arranged();
		p->color_hovered = n_bmp_hsl_replace_pixel( p->color_hovered, -1, 200, 128 );
	} else
	if ( n_win_color_is_highcontrast() )
	{
		p->color_fg      = n_bmp_rgb( 128,128,128 );;
		p->color_pressed = n_gdi_systemcolor( COLOR_3DDKSHADOW );
		p->color_hovered = n_gdi_systemcolor( COLOR_HIGHLIGHT  );
	} else {
		// [x] : Win95 : COLOR_3DDKSHADOW is always white

		u32 color_1 = n_gdi_systemcolor( COLOR_WINDOW     );
		u32 color_2 = n_gdi_systemcolor( COLOR_WINDOWTEXT );

		p->color_fg      = n_gdi_systemcolor( COLOR_GRAYTEXT   );
		p->color_pressed = n_bmp_blend_pixel( color_1, color_2, 0.75 );
		//p->color_hovered = n_gdi_systemcolor( COLOR_HIGHLIGHT  );
		//p->color_hovered = n_bmp_hsl_replace_pixel( p->color_hovered, -1, 255, 128 );
		p->color_hovered = n_win_dwm_windowcolor_arranged();
		p->color_hovered = n_bmp_hsl_replace_pixel( p->color_hovered, -1, 200, 128 );
	}


	// [!] : default bitmap : delayed for override p->color_bg

	p->make_default = n_posix_true;


	return;
}

#define n_win_smallbutton_direct_init(         p, hd, ht, hm, id, i ) n_win_smallbutton_direct_init_internal( p, hd, ht, hm, id, i, NULL )
#define n_win_smallbutton_direct_init_by_data( p, hd, ht, hm, id, d ) n_win_smallbutton_direct_init_internal( p, hd, ht, hm, id, 0,    d )

void
n_win_smallbutton_direct_init_internal
(
	n_win_smallbutton_direct *p,
	HWND                      hwnd_draw,
	HWND                      hwnd_timer,
	HWND                      hwnd_msg,
	int                       id,
	int                       index,
	const u8                 *data
)
{

	n_win_smallbutton_direct_on_settingchange_internal( p, index, data );

	p->hwnd_draw  = hwnd_draw;
	p->hwnd_timer = hwnd_timer;
	p->hwnd_msg   = hwnd_msg;
	p->id         = id;
	p->state      = N_WIN_SMALLBUTTON_DIRECT_NONE;

	n_bmp_fade_init( &p->fade, p->color_fg );

	return;
}

void
n_win_smallbutton_direct_exit( n_win_smallbutton_direct *p )
{

	// Resource

	n_win_icon_exit( p->hicon );

	n_bmp_free( &p->b );
	n_bmp_free( &p->m );

	n_bmp_free( &p->bmp_default );
	n_bmp_free( &p->bmp         );


	// Cleanup

	n_win_smallbutton_direct_zero( p );


	return;
}

void
n_win_smallbutton_direct_on_settingchange( n_win_smallbutton_direct *p, const u8 *data )
{

	HWND         hwnd_draw     = p->hwnd_draw;
	HWND         hwnd_timer    = p->hwnd_timer;
	HWND         hwnd_msg      = p->hwnd_msg;
	int          id            = p->id;
	n_posix_bool show_onoff    = p->show_onoff;
	u32          color_fg      = p->color_fg;
	u32          color_bg      = p->color_bg;
	u32          color_pressed = p->color_pressed;
	u32          color_hovered = p->color_hovered;

	n_win_smallbutton_direct_exit( p );

	n_win_smallbutton_direct_init_by_data
	(
		p,
		hwnd_draw,
		hwnd_timer,
		hwnd_msg,
		id,
		data
	);

	p->show_onoff    = show_onoff;
	p->color_fg      = color_fg;
	p->color_bg      = color_bg;
	p->color_pressed = color_pressed;
	p->color_hovered = color_hovered;


	return;
}

n_posix_bool
n_win_smallbutton_direct_is_hovered( n_win_smallbutton_direct *p )
{
	return n_win_is_hovered_offset( p->hwnd_draw, p->x, p->y, p->sx, p->sy );
}

n_posix_bool
n_win_smallbutton_direct_is_pressed( n_win_smallbutton_direct *p )
{
	return ( p->state & N_WIN_SMALLBUTTON_DIRECT_PRESSED );
}

void
n_win_smallbutton_direct_hide( n_win_smallbutton_direct *p, n_posix_bool redraw )
{

	if ( p == NULL ) { return; }


	p->show_onoff = n_posix_false;
	p->state      = N_WIN_SMALLBUTTON_DIRECT_NONE;
	p->fade_blend = 0.0;

	n_bmp_fade_init( &p->fade, p->color_fg );


	if ( redraw )
	{
		n_win_smallbutton_direct_bitmap_init( p );
	}


	return;
}

void
n_win_smallbutton_direct_press( n_win_smallbutton_direct *p, n_posix_bool onoff, n_posix_bool redraw )
{

	if ( p == NULL ) { return; }


	if ( onoff )
	{
		p->state |=  N_WIN_SMALLBUTTON_DIRECT_PRESSED;
	} else {
		p->state &= ~N_WIN_SMALLBUTTON_DIRECT_PRESSED;
	}


	if ( redraw )
	{
		n_win_smallbutton_direct_bitmap_init_lite( p );
	}


	return;
}

#define n_win_smallbutton_direct_hover( p, onoff, redraw ) n_win_smallbutton_direct_hover_main( p, onoff, n_posix_true, redraw )

void
n_win_smallbutton_direct_hover_main( n_win_smallbutton_direct *p, n_posix_bool onoff, n_posix_bool timer_onoff, n_posix_bool redraw )
{

	if ( p == NULL ) { return; }


	n_posix_bool p_state = p->state;

	if ( onoff )
	{
		p->state |=  N_WIN_SMALLBUTTON_DIRECT_HOVERED;
	} else {
		p->state &= ~N_WIN_SMALLBUTTON_DIRECT_HOVERED;
	}


	if ( p_state != p->state )
	{
//n_posix_debug_literal( " Changed " );

		u32 bg,fg;
		if ( p->state & N_WIN_SMALLBUTTON_DIRECT_HOVERED )
		{
			bg = p->color_fg;
			fg = p->color_hovered;
		} else {
			bg = p->color_hovered;
			fg = p->color_fg;
		}

		n_bmp_fade_init( &p->fade, bg );
		n_bmp_fade_go  ( &p->fade, fg );

		if ( timer_onoff )
		{
			if ( p->fade_timer == 0 ) { p->fade_timer = n_win_timer_id_get(); }
			n_win_timer_init( p->hwnd_timer, p->fade_timer, 33 );
		}
	}


	if ( redraw )
	{
		n_win_smallbutton_direct_bitmap_init( p );
	}


	return;
}

void
n_win_smallbutton_direct_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_win_smallbutton_direct *p )
{
//return;

	switch( msg ) {


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( p->fade_timer == wparam )
		{
//n_posix_debug_literal( " WM_TIMER " );
			n_win_smallbutton_direct_bitmap_init( p );
			n_win_smallbutton_direct_bitmap_draw( p );

			if ( p->fade.stop ) { n_win_timer_exit( p->hwnd_timer, p->fade_timer ); }

		}

	break;


	case WM_PAINT :

		// [!] : you need to control manually

		//n_win_smallbutton_direct_bitmap_draw( p );

	break;


	case WM_LBUTTONDOWN   :
	case WM_LBUTTONDBLCLK :
	{

		if ( p->show_onoff == n_posix_false ) { break; }

		n_posix_bool onoff = n_win_smallbutton_direct_is_hovered( p );
		if ( onoff )
		{
//n_posix_debug_literal( " WM_LBUTTONDOWN " );
			n_win_smallbutton_direct_press( p, n_posix_true, n_posix_true );
			n_win_smallbutton_direct_bitmap_draw( p );
		}
	}
	break;

	case WM_LBUTTONUP :

		if ( p->show_onoff == n_posix_false ) { break; }

		if ( n_win_smallbutton_direct_is_pressed( p ) )
		{
//n_posix_debug_literal( " WM_LBUTTONUP " );
			n_win_smallbutton_direct_press( p, n_posix_false, n_posix_true );
			n_win_smallbutton_direct_bitmap_draw( p );

			if ( n_win_smallbutton_direct_is_hovered( p ) )
			{
				n_win_message_post( p->hwnd_msg, WM_COMMAND, p->id, p->hwnd_msg );
			}
		}

	break;

	case WM_MOUSEMOVE :
	{

		if ( p->show_onoff == n_posix_false ) { break; }

		int p_state = p->state;

		n_posix_bool onoff = n_win_smallbutton_direct_is_hovered( p );
		if ( onoff == n_posix_false )
		{
			if ( n_win_smallbutton_direct_is_pressed( p ) )
			{
				n_win_smallbutton_direct_press( p, n_posix_false, n_posix_true );
			}
		}

		n_win_smallbutton_direct_hover( p, onoff, n_posix_false );

		if ( p_state != p->state )
		{
//n_posix_debug_literal( " WM_MOUSEMOVE " );
			n_win_smallbutton_direct_bitmap_draw( p );
		}

	}
	break;

	} // switch


	return;
}


#endif // _H_NONNON_WIN32_WIN_SMALLBUTTON_DIRECT


