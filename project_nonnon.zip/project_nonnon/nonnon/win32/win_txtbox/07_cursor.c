// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_win_txtbox_cursor_add( n_win_txtbox *p, n_posix_char *idc )
{

	n_win_cursor_add( p->hwnd, idc );
	n_win_cursor_add(    NULL, idc );


	return;
}

void
n_win_txtbox_on_setcursor( n_win_txtbox *p )
{

	// [x] : static ownerdraw and disabled controls are excluded;

	if ( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX ) )
	{

		n_win_txtbox_cursor_add( p, IDC_ARROW );

	} else
	if ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_NOIBEAM )
	{

		n_win_txtbox_cursor_add( p, IDC_ARROW );
/*
		// [!] : no ibeam when normal, ibeam when IME is ON

		extern n_posix_bool n_win_txtbox_is_hovered( n_win_txtbox* );

		if (
			( p->ime_onoff )
			&&
			( p->menu_onoff == n_posix_false )
			&&
			( p->is_hovered_linenum == n_posix_false )
			&&
			( n_win_txtbox_is_hovered( p ) )
			&&
			( p->hwnd == n_win_cursor2hwnd_relative( n_win_hwnd_toplevel( p->hwnd ) ) )
		)
		{
			n_win_txtbox_cursor_add( p, IDC_IBEAM );
		} else {
			n_win_txtbox_cursor_add( p, IDC_ARROW );
		}
*/
	} else {
//n_win_txtbox_hwndprintf_literal( p, " 0 " );
//n_win_txtbox_cursor_add( p, IDC_IBEAM ); return;

		extern n_posix_bool n_win_txtbox_is_hovered( n_win_txtbox* );

		n_posix_bool is_hovered = n_win_txtbox_is_hovered( p );

		if ( p->menu_onoff )
		{

			n_win_txtbox_cursor_add( p, IDC_ARROW );

		} else
		if ( is_hovered == n_posix_false )
		{

			n_win_txtbox_cursor_add( p, IDC_ARROW );

		} else {

			if (
				( p->smallbutton_margin == 0 )
				||
				( n_posix_false == IsWindowVisible( n_win_cursor2hwnd_relative( n_win_hwnd_toplevel( p->hwnd ) ) ) )
			)
			{
//n_win_txtbox_hwndprintf_literal( p, " 1 " );
				n_win_txtbox_cursor_add( p, IDC_IBEAM );
			} else

			if (
				( p->menu_onoff         == n_posix_false )
				&&
				( p->is_hovered_linenum == n_posix_false )
				&&
				( p->hwnd == n_win_cursor2hwnd_relative( n_win_hwnd_toplevel( p->hwnd ) ) )
			)
			{
//n_win_txtbox_hwndprintf_literal( p, " 2 " );
				n_win_txtbox_cursor_add( p, IDC_IBEAM );
			}

		}

	}


	return;
}


